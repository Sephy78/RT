
<?php


$bdd = new PDO('mysql:host=localhost;dbname=BetterCallFlix', 'root','');

//$mails=htmlspecialchars($_POST['mail']);

// function existeMail($mails)
// {   
//     global $bdd;
     
//     $sql = "SELECT 1 FROM Utilisateurs WHERE Email = '$mails'";
     
//     $res = $bdd->query($sql);
//     $row = $res->fetch();
     	
//     return !empty($row);
// }

// if (existeMail($mails)){
// 	echo "<p> Mail Déja Utilisé! </p>";
// 	header('refresh:1,url=..index.html');
// }else{

if (isset($_POST['valider1'])){	
	$mdp=sha1($_POST['mdp']);
	$mail=htmlspecialchars($_POST['mail']);
	$register=$bdd->prepare("INSERT INTO Utilisateurs( Email , Password ) VALUES('$mail', '$mdp')");
	$register->execute(array($mail,$mdp));

    $userinfo = $register->fetch();
    session_start();
    $_SESSION['Email'] = $userinfo['Email'];
    header("location: watch.php" .$_SESSION['mail'])   ;   
}
	//}


?>

