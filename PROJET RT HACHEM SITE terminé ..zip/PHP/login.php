<?php 


// $bdd = new PDO('mysql:host=localhost;dbname=BetterCallFlix', 'root', 'root');
// //  Récupération de l'utilisateur et de son pass hashé
// $mail=$_POST["mail2"];
// $req = $bdd->prepare('SELECT Email, Password FROM Utilisateurs WHERE Email = $mail ' );
// $resultat = $req->fetch();

// // Comparaison du pass envoyé via le formulaire avec la base
// $isPasswordCorrect = password_verify(sha1($_POST['mdp2']), $resultat['Password']);
// echo $isPasswordCorrect;


// if ($isPasswordCorrect) {
//     session_start();
//     $_SESSION['Email'] = $resultat['Email'];
//     echo"tcho";
// }
// else {
//     echo 'Mauvais identifiant ou mot de passe !';
// }


// if(isset($_POST['connect1'])) {
//    $mailconnect = htmlspecialchars($_POST['mail2']);
//    $mdpconnect = sha1($_POST['mdp2']);
//    if(!empty($mailconnect) AND !empty($mdpconnect)) {
//    	  $bdd = new PDO('mysql:host=localhost;dbname=BetterCallFlix', 'root', 'root');
//       $requser = $bdd->prepare("SELECT * FROM Utilisateurs WHERE Email = ? AND Password= ? ");
//       $requser->execute(array($mailconnect, $mdpconnect));
//       $userexist = $requser->rowCount();
//       echo $userexist; 
//       if($userexist == 1) {
//       	 $userinfo = $requser->fetch();
//          $_SESSION['Email'] = $userinfo['Email'];
//      	}else{

//      }
// }


// 

if(isset($_POST['connect1'])) {
	 $mailconnect = htmlspecialchars($_POST['mail2']);
	 $mdpconnect = sha1($_POST['mdp2']);
	 if(!empty($mailconnect) AND !empty($mdpconnect)) {
	    $bdd = new PDO('mysql:host=localhost;dbname=BetterCallFlix', 'root', '');
	    $requser = $bdd->prepare("SELECT * FROM Utilisateurs WHERE Email = ? AND Password= ? ");
	    $requser->execute(array($mailconnect, $mdpconnect));
	    $userexist = $requser->rowCount();
	    echo $userexist; 
	    if($userexist == 1) {
	       $userinfo = $requser->fetch();
	       session_start();
	       $_SESSION['Email'] = $userinfo['Email'];
	       header("location: /PROJET RT HACHEM SITE/watch.php" .$_SESSION['mail'])   ;   
	   	}
	}

}
?>